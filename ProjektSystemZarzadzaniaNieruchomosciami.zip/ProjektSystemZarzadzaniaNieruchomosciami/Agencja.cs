﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    [DataContract]
    public class AgencjaXmlException : Exception
    {
        public AgencjaXmlException() { }
        public AgencjaXmlException(string message) : base(message) { }
    }
    public class Agencja
    {
        private string nazwaAgencji;
        private Kierownik kierownikAgencji;
        private string miasto;
        private static List<Agencja> agencje = new();

        [DataMember]
        public string NazwaAgencji
        {
            get => nazwaAgencji;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Nazwa agencji nie może być pusta.");
                }
                nazwaAgencji = value;
            }
        }
        [DataMember]
        public Kierownik KierownikAgencji
        {
            get => kierownikAgencji;
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(nameof(KierownikAgencji), "Kierownik agencji nie może być null.");
                }
                kierownikAgencji = value;
            }
        }
        [DataMember]
        public string Miasto
        {
            get => miasto;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Miasto nie może być puste.");
                }
                miasto = value;
            }
        }


        public Agencja() { }
        public Agencja(string nazwaOddzial, Kierownik kierownikAgencji, string miasto)
        {
            NazwaAgencji = nazwaOddzial;
            KierownikAgencji = kierownikAgencji;
            Miasto = miasto;

        }




        public override string ToString()
        {
            return $"Nazwa agencji: {NazwaAgencji}, Miasto: {Miasto}, Kierownik: {KierownikAgencji.Imie} {KierownikAgencji.Nazwisko}";
        }




        public static void ZapiszAgencjeXml(string nazwaPliku, List<Agencja> agencje)
        {
            try
            {
                DataContractSerializer dsc = new(typeof(List<Agencja>));
                using XmlTextWriter writer = new(nazwaPliku, Encoding.UTF8);
                dsc.WriteObject(writer, agencje);
                Console.WriteLine("Zapisano listę agencji do pliku XML.");
            }
            catch
            {
                throw new AgencjaXmlException($"Błąd podczas zapisu listy agencji do pliku XML: {nazwaPliku}");
            }
        }

        public static List<Agencja>? OdczytajAgencjeXml(string nazwaPliku)
        {
            if (!File.Exists(nazwaPliku)) { return null; }
            try
            {
                DataContractSerializer dsc = new(typeof(List<Agencja>));
                using XmlTextReader reader = new(nazwaPliku);
                return (List<Agencja>?)dsc.ReadObject(reader);
            }
            catch
            {
                throw new AgencjaXmlException($"Błąd podczas odczytu listy agencji z pliku XML: {nazwaPliku}");
            }
        }


    }

}