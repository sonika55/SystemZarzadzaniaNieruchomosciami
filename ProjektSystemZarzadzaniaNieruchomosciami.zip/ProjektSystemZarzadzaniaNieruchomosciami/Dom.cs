﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    [DataContract]
    public class Dom : Nieruchomosc
    {
        [DataMember]
        public int liczbaPietr { get; set; }
        [DataMember]
        public bool garaz { get; set; }
        [DataMember]
        public bool ogrodek { get; set; }

        public Dom() { }
        public Dom(EnumNieruchomosc nieruch, string kodPocztowy, string miasto, string ulica, string numerDomu, EnumRodzaj rodzaj, int liczbaPokoi, bool wolny, bool zwierzeta, bool palenie, int powierzchnia, int liczbaPietr, bool garaz, bool ogrodek, Agencja agencja)
                   : base(nieruch, kodPocztowy, miasto, ulica, numerDomu, rodzaj, liczbaPokoi, wolny, zwierzeta, palenie, powierzchnia, agencja)
        {
            this.liczbaPietr = liczbaPietr;
            this.garaz = garaz;
            this.ogrodek = ogrodek;
            CenaPodstawowa = UstalCenePodstawowa(rodzaj, true);
        }
        public override double ObliczCene(DateTime dataWynajecia, DateTime dataZwolnienia)
        {

            double podstawowaCena = base.ObliczCene(dataWynajecia, dataZwolnienia);
            double kosztGarazu = garaz ? 100 : 0; // stały koszt za garaż
            double kosztOgrodek = ogrodek ? 100 : 0; // koszt za ogródek
            double kosztPietra = liczbaPietr * 5; // koszt zależny od liczby pięter



            return podstawowaCena + kosztGarazu + kosztOgrodek + kosztPietra;
        }

        public override string ToString()
        {
            return $"{base.ToString()}Garaż: {(garaz ? "Tak" : "Nie")}, Ogródek: {(ogrodek ? "Tak" : "Nie")}\n";
        }
    }
}