﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    [DataContract]

    public class Kierownik : Osoba
    {
        public Kierownik() { }
        public Kierownik(string imie, string nazwisko, string numerTelefonu, string pesel, string dataUrodzenia)
            : base(imie, nazwisko, numerTelefonu, pesel, dataUrodzenia)
        {
        }
    }
}