﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjektZarzadzanieGUI
{
    public partial class WolneNieruchomosci : Window
    {
        public WolneNieruchomosci()
        {
            InitializeComponent();
            LoadWolneNieruchomosci();
        }

        private void LoadWolneNieruchomosci()
        {
            try
            {
                string nazwaPliku = "nieruchomosci.xml";
                var wszystkieNieruchomosci = Nieruchomosc.OdczytajNieruchomoscXml(nazwaPliku);
                Wynajecie.UstawListeWolnychNieruchomosci(wszystkieNieruchomosci);
                dgWolneNieruchomosci.ItemsSource = Wynajecie.ListaWolnychNieruchomosci;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas ładowania nieruchomości: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SortujIPrzeladujDane(Action sortAction)
        {
            sortAction();
            dgWolneNieruchomosci.Items.Refresh();
        }

        private void SortujPoCenie_Click(object sender, RoutedEventArgs e)
        {
            SortujIPrzeladujDane(Wynajecie.SortujWolnePoCenie);
        }

        private void SortujPoPowierzchni_Click(object sender, RoutedEventArgs e)
        {
            SortujIPrzeladujDane(Wynajecie.SortujWolnePoPowierzchni);
        }

        private void ZapiszZmiany_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Nieruchomosc.ZapiszNieruchomoscXml("nieruchomosci.xml", Wynajecie.ListaWolnychNieruchomosci);
                MessageBox.Show("Zmiany zapisane pomyślnie!", "Informacja", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas zapisywania: {ex.Message}", "Błąd", MessageBoxButton.OK);
            }
        }
    }

}