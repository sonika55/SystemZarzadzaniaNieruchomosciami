﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace ProjektZarzadzanieGUI
{
    /// <summary>
    /// Interaction logic for ZarzadzajWynajmem.xaml
    /// </summary>
    public partial class ZarzadzajWynajmem : Window
    {
        public ZarzadzajWynajmem()
        {
            InitializeComponent();
            LoadWynajmy();
        }

        private void LoadWynajmy()
        {
            if (Wynajecie.ListaWynajmowan != null)
            {
                Wynajecie.ListaWynajmowan.Clear();
            }

            string nazwaPliku = "wynajmy.xml";
            Wynajecie.OdczytajWynajmyXml(nazwaPliku);


            foreach (var wynajem in Wynajecie.ListaWynajmowan)
            {

                double cena = wynajem.Cena;

            }
            RefreshDataGrid();

        }



        private void BtnZwolnij_Click(object sender, RoutedEventArgs e)
        {
            if (dgWynajmy.SelectedItem is Wynajecie selectedWynajecie)
            {
                Wynajecie.Zwolnij(selectedWynajecie.wynajetyObiekt);
                LoadWynajmy();
                MessageBox.Show($"Zwolniono nieruchomość: {selectedWynajecie.wynajetyObiekt.Identyfikator}", "Sukces");
            }
            else
            {
                MessageBox.Show("Wybierz wynajem do zwolnienia.", "Błąd");
            }
        }

        private void BtnShowDetails_Click(object sender, RoutedEventArgs e)
        {
            if (dgWynajmy.SelectedItem is Wynajecie selectedWynajecie)
            {
                MessageBox.Show(
                    $"Klient: {selectedWynajecie.wynajecieKlient.Imie} {selectedWynajecie.wynajecieKlient.Nazwisko}\n" +
                    $"Nieruchomość: {selectedWynajecie.wynajetyObiekt.Identyfikator}\n" +
                    $"Data wynajęcia: {selectedWynajecie.DataWynajecia:dd-MM-yyyy}\n" +
                    $"Data zwolnienia: {selectedWynajecie.DataZwolnienia:dd-MM-yyyy}\n" +
                    $"Cena: {selectedWynajecie.Cena:C2}\n" +
                    $"Agencja: {selectedWynajecie.wynajetyObiekt.AgencjaPrzypisana.NazwaAgencji}\n" +
                    $"PESEL: {selectedWynajecie.wynajecieKlient.Pesel}\n",
                    "Szczegóły wynajmu",
                    MessageBoxButton.OK

                );
            }
            else
            {

                MessageBox.Show("Wybierz nieruchomość, aby zobaczyć szczegóły.", "Błąd", MessageBoxButton.OK);
            }
        }

        public void RefreshDataGrid()
        {
            dgWynajmy.ItemsSource = null;
            dgWynajmy.ItemsSource = Wynajecie.ListaWynajmowan;
        }

        private void BtnAddWynajem_Click(object sender, RoutedEventArgs e)
        {
            var dodajWynajem = new DodajWynajem();


            if (dodajWynajem.ShowDialog() == true)
            {

                Wynajecie.ZapiszWynajmyXml("wynajmy.xml");
                RefreshDataGrid();
            }
        }



    }
}