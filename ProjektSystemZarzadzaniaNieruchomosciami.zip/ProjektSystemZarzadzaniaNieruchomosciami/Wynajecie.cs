﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    public class FormatDatyException : Exception
    {
        public FormatDatyException() { }
        public FormatDatyException(string message) : base(message) { }
    }

    [DataContract]
    internal class NazwaComparer : Comparer<Wynajecie>
    {
        public override int Compare(Wynajecie? x, Wynajecie? y)
        {
            if (x == null || y == null) return 0;

            int wynikNazwisko = string.Compare(x.wynajecieKlient.Nazwisko, y.wynajecieKlient.Nazwisko, StringComparison.OrdinalIgnoreCase);
            if (wynikNazwisko != 0)
            {
                return wynikNazwisko;
            }
            return string.Compare(x.wynajecieKlient.Imie, y.wynajecieKlient.Imie, StringComparison.OrdinalIgnoreCase);
        }

    }
    public class Wynajecie : IComparable<Wynajecie>
    {

        [DataMember]
        static int biezaceWynajecie { get; set; }
        [DataMember]
        public string numerWynajecia { get; set; }
        [DataMember]
        public Klient wynajecieKlient { get; set; }
        [DataMember]
        public Nieruchomosc wynajetyObiekt { get; set; }
        private DateTime dataWynajecia;
        private DateTime dataZwolnienia;
        [DataMember]
        public int LiczbaDni => (DataZwolnienia - DataWynajecia).Days;
        [DataMember]
        public static List<Nieruchomosc> ListaWolnychNieruchomosci { get; private set; } = new List<Nieruchomosc>();

        [DataMember]
        private static List<Wynajecie> listaWynajmowan = new List<Wynajecie>();
        [DataMember]
        public static List<Wynajecie> ListaWynajmowan
        {
            get => listaWynajmowan;
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(nameof(ListaWynajmowan), "Lista wynajmowań nie może być null.");
                }
                listaWynajmowan = value;
            }
        }
        [DataMember]
        public DateTime DataWynajecia { get => dataWynajecia; set => dataWynajecia = value; }
        [DataMember]
        public DateTime DataZwolnienia { get => dataZwolnienia; set => dataZwolnienia = value; }
        [DataMember]
        public double Cena
        {
            get
            {
                return wynajetyObiekt.ObliczCene(DataWynajecia, DataZwolnienia);
            }
        }


        public Wynajecie()
        {
        }

        public Wynajecie(Klient wynajecieKlient, Nieruchomosc nieruchomosc, string dataWynajecia, string dataZwolnienia)
        {
            if (nieruchomosc == null)
            {
                throw new ArgumentNullException(nameof(nieruchomosc), "Nieruchomość nie może być null.");
            }

            if (!nieruchomosc.Wolny)
            {
                throw new Exception($"Nieruchomość {nieruchomosc.Identyfikator} jest zajęta.");
            }

            this.wynajecieKlient = wynajecieKlient;
            this.wynajetyObiekt = nieruchomosc;


            if (!DateTime.TryParseExact(dataWynajecia, new[] { "dd-MM-yyyy", "yyyy-MM-dd" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out this.dataWynajecia))
            {
                throw new FormatDatyException("Niepoprawny format daty wynajęcia. Użyj formatu dd-MM-yyyy lub yyyy-MM-dd.");
            }

            if (!DateTime.TryParseExact(dataZwolnienia, new[] { "dd-MM-yyyy", "yyyy-MM-dd" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out this.dataZwolnienia))
            {
                throw new FormatDatyException("Niepoprawny format daty zwolnienia. Użyj formatu dd-MM-yyyy lub yyyy-MM-dd.");
            }

            if (this.dataWynajecia >= this.dataZwolnienia)
            {
                throw new FormatDatyException("Data zwolnienia musi być późniejsza niż data wynajęcia.");
            }


            nieruchomosc.Wolny = false;
        }


        public override string ToString()
        {
            return $"Numer wynajęcia: {numerWynajecia}\n" +
                   $"Klient: {wynajecieKlient.Imie} {wynajecieKlient.Nazwisko}\n" +
                   $"Mieszkanie: {wynajetyObiekt.Identyfikator} ({wynajetyObiekt.Miasto})\n" +
                   $"Od: {DataWynajecia:d}, Do: {DataZwolnienia:d} ({LiczbaDni} dni)";
        }

        public static bool CzyWolna(Nieruchomosc nieruchomosc)
        {
            if (nieruchomosc == null)
                throw new ArgumentNullException(nameof(nieruchomosc), "Nieruchomość nie może być null.");
            return nieruchomosc.Wolny;
        }

        public static void DodajWynajecie(Wynajecie wynajecie)
        {
            if (wynajecie == null)
                throw new ArgumentNullException(nameof(wynajecie), "Dodawane wynajęcie nie może być null.");

            ListaWynajmowan.Add(wynajecie);
            wynajecie.wynajetyObiekt.Wolny = false;
        }

        public static void Zwolnij(Nieruchomosc nieruchomosc)
        {
            if (nieruchomosc == null)
                throw new ArgumentNullException(nameof(nieruchomosc), "Nieruchomość do zwolnienia nie może być null.");

            var wynajem = ListaWynajmowan.FirstOrDefault(w => w.wynajetyObiekt == nieruchomosc);
            if (wynajem != null)
            {
                wynajem.wynajetyObiekt.Wolny = true;
                ListaWynajmowan.Remove(wynajem);
            }
        }



        public int CompareTo(Wynajecie? obj)
        {
            if (obj == null) return 1;

            return DataZwolnienia.CompareTo(obj.DataZwolnienia);
        }

        public static void UstawListeWolnychNieruchomosci(List<Nieruchomosc> wszystkieNieruchomosci)
        {

            ListaWolnychNieruchomosci = wszystkieNieruchomosci.Where(n => n.Wolny).ToList();
        }

        public static void SortujWolnePoCenie()
        {
            ListaWolnychNieruchomosci.Sort((x, y) => x.CenaPodstawowa.CompareTo(y.CenaPodstawowa));
        }

        public static void SortujWolnePoPowierzchni()
        {
            ListaWolnychNieruchomosci.Sort((x, y) => x.Powierzchnia.CompareTo(y.Powierzchnia));
        }

        public static void ZapiszWynajmyXml(string nazwaPliku)
        {
            try
            {
                if (ListaWynajmowan == null || ListaWynajmowan.Count == 0)
                {
                    Console.WriteLine("Brak wynajmów do zapisania.");
                    return;
                }

                XmlSerializer serializer = new XmlSerializer(typeof(List<Wynajecie>));
                using (StreamWriter writer = new StreamWriter(nazwaPliku, false, Encoding.UTF8))
                {
                    serializer.Serialize(writer, ListaWynajmowan);
                }
                Console.WriteLine("Zapisano listę wynajmów do pliku XML.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas zapisu wynajmów: {ex.Message}");
                throw;
            }
        }



        public static void OdczytajWynajmyXml(string nazwaPliku)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Wynajecie>));
                using (StreamReader reader = new StreamReader(nazwaPliku, Encoding.UTF8))
                { ListaWynajmowan = (List<Wynajecie>)serializer.Deserialize(reader); }
                Console.WriteLine("Dane wynajmów załadowane z pliku XML.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas odczytu danych z pliku XML: {ex.Message}");
            }
        }


        public static void WolneNieruchomosci()
        {
            List<Nieruchomosc> wszystkieNieruchomosci = Program.IstniejaceNieruchomosci();
            Wynajecie.UstawListeWolnychNieruchomosci(wszystkieNieruchomosci);
            Console.WriteLine("Wolne nieruchomości:");
            foreach (var nieruchomosc in Wynajecie.ListaWolnychNieruchomosci)
            {
                Console.WriteLine($"Cena: {nieruchomosc.CenaPodstawowa}, Powierzchnia: {nieruchomosc.Powierzchnia}");
            }


            Wynajecie.SortujWolnePoCenie();
            Console.WriteLine("\nWolne nieruchomości posortowane po cenie:");
            foreach (var nieruchomosc in Wynajecie.ListaWolnychNieruchomosci)
            {
                Console.WriteLine($"Cena: {nieruchomosc.CenaPodstawowa}, Powierzchnia: {nieruchomosc.Powierzchnia}");
            }


            Wynajecie.SortujWolnePoPowierzchni();
            Console.WriteLine("\nWolne nieruchomości posortowane po powierzchni:");
            foreach (var nieruchomosc in Wynajecie.ListaWolnychNieruchomosci)
            {
                Console.WriteLine($"Powierzchnia: {nieruchomosc.Powierzchnia}, Cena: {nieruchomosc.CenaPodstawowa}");
            }
        }


    }
}