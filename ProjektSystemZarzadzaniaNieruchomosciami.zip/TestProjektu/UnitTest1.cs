using ProjektSystemZarzadzaniaNieruchomosciami;

namespace TestProjektu
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPustaNazwaAgencji()
        {
            // arrange & action
            Agencja agencja = new() { NazwaAgencji = "" };

            // assert
            Assert.Fail("Nie powinno by� mo�liwe ustawienie pustej nazwy agencji.");
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullowyKierownikAgencji()
        {
            // arrange & action
            Agencja agencja = new() { KierownikAgencji = null };

            // assert
            Assert.Fail("Nie powinno by� mo�liwe ustawienie nullowego kierownika agencji.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPusteMiastoAgencji()
        {
            // arrange & action
            Agencja agencja = new() { Miasto = "" };

            // assert
            Assert.Fail("Nie powinno by� mo�liwe ustawienie pustej warto�ci dla miasta.");
        }


        [TestMethod]
        public void TestDodawaniaAgencjiDoListy()
        {
            // arrange
            Agencja agencja1 = new("Agencja1", new Kierownik("Jan", "Kowalski", "111222333", "12344567789", "13-06-1978"), "Warszawa");
            Agencja agencja2 = new("Agencja2", new Kierownik("Anna", "Nowak", "444555666", "54561456827", "21-05-1990"), "Krak�w");
            List<Agencja> agencje = new();

            // action
            agencje.Add(agencja1);
            agencje.Add(agencja2);

            // assert
            Assert.AreEqual(2, agencje.Count, "Lista agencji powinna zawiera� 2 elementy.");
            Assert.IsTrue(agencje.Contains(agencja1), "Lista powinna zawiera� agencj� 1.");
            Assert.IsTrue(agencje.Contains(agencja2), "Lista powinna zawiera� agencj� 2.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestDodajWynajecie_NullWynajecie_ThrowsException()
        {
            // action
            Wynajecie.DodajWynajecie(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestZwolnij_NullNieruchomosc_ThrowsException()
        {
            // action
            Wynajecie.Zwolnij(null);
        }

        [TestMethod]
        public void TestDodajWynajecie_PoprawneDane_Sukces()
        {
            // arrange
            var nieruchomosc = new Nieruchomosc { Wolny = true, Identyfikator = "N1" };
            var klient = new Klient("Jan", "Kowalski", "111222333", "12345678901", "01-01-1980");
            var wynajecie = new Wynajecie(klient, nieruchomosc, "01-01-2025", "10-01-2025");

            // action
            Wynajecie.DodajWynajecie(wynajecie);

            // assert
            Assert.IsFalse(nieruchomosc.Wolny, "Nieruchomo�� powinna by� oznaczona jako zaj�ta.");
            Assert.IsTrue(Wynajecie.ListaWynajmowan.Contains(wynajecie), "Lista wynajmowa� powinna zawiera� nowy wynajem.");
        }


        [TestMethod]
        public void TestZwolnij_PoprawneDane_Sukces()
        {
            // arrange
            var nieruchomosc = new Nieruchomosc { Wolny = true, Identyfikator = "N1" }; // Nieruchomo�� musi by� wolna
            var klient = new Klient("Anna", "Nowak", "444555666", "12345678901", "15-05-1990");
            var wynajecie = new Wynajecie(klient, nieruchomosc, "01-01-2025", "10-01-2025");
            Wynajecie.DodajWynajecie(wynajecie);

            // action
            Wynajecie.Zwolnij(nieruchomosc);

            // assert
            Assert.IsTrue(nieruchomosc.Wolny, "Nieruchomo�� powinna by� oznaczona jako wolna.");
            Assert.IsFalse(Wynajecie.ListaWynajmowan.Contains(wynajecie), "Lista wynajmowa� nie powinna zawiera� zwolnionego wynajmu.");
        }



        [TestMethod]
        [ExpectedException(typeof(FormatDatyException))]
        public void TestNiepoprawnyFormatDatyWynajecia_ThrowsException()
        {
            // arrange
            var nieruchomosc = new Nieruchomosc { Wolny = true, Identyfikator = "N1" };
            var klient = new Klient("Adam", "Nowak", "555666777", "98712345603", "10-10-1995");

            // action
            new Wynajecie(klient, nieruchomosc, "01-2025", "10-01-2025");
        }



        [TestMethod]
        [ExpectedException(typeof(FormatDatyException))]
        public void TestDataZwolnieniaPrzedDataWynajecia_ThrowsException()
        {
            // arrange
            var nieruchomosc = new Nieruchomosc { Wolny = true, Identyfikator = "N1" };
            var klient = new Klient("Ewa", "Kowalska", "888999000", "12345678901", "20-10-1990");

            // action
            new Wynajecie(klient, nieruchomosc, "10-01-2025", "01-01-2025");
        }



        [TestMethod]
        public void TestUstawListeWolnychNieruchomosci_FiltrujeWolneNieruchomosci()
        {
            // arrange
            var nieruchomosc1 = new Nieruchomosc { Wolny = true, Identyfikator = "N1" };
            var nieruchomosc2 = new Nieruchomosc { Wolny = false, Identyfikator = "N2" };
            var nieruchomosc3 = new Nieruchomosc { Wolny = true, Identyfikator = "N3" };
            var wszystkieNieruchomosci = new List<Nieruchomosc> { nieruchomosc1, nieruchomosc2, nieruchomosc3 };

            // action
            Wynajecie.UstawListeWolnychNieruchomosci(wszystkieNieruchomosci);

            // assert
            Assert.AreEqual(2, Wynajecie.ListaWolnychNieruchomosci.Count, "Lista wolnych nieruchomo�ci powinna zawiera� tylko wolne obiekty.");
            Assert.IsTrue(Wynajecie.ListaWolnychNieruchomosci.Contains(nieruchomosc1), "Lista wolnych nieruchomo�ci powinna zawiera� nieruchomo�� N1.");
            Assert.IsTrue(Wynajecie.ListaWolnychNieruchomosci.Contains(nieruchomosc3), "Lista wolnych nieruchomo�ci powinna zawiera� nieruchomo�� N3.");
        }

        [TestMethod]
        public void TestTworzenieDomu_PoprawneDane()
        {
            // arrange
            var agencja = new Agencja { NazwaAgencji = "Agencja Testowa" };

            // act
            var dom = new Dom(EnumNieruchomosc.Dom, "01-234", "Warszawa", "Mokotowska", "15", EnumRodzaj.Luksus, 5, true, true, true, 120, 2, true, true, agencja);

            // assert
            Assert.AreEqual("01-234", dom.KodPocztowy, "Kod pocztowy nie zosta� ustawiony poprawnie.");
            Assert.AreEqual("Warszawa", dom.Miasto, "Miasto nie zosta�o ustawione poprawnie.");
            Assert.AreEqual("Luksus", dom.Rodzaj.ToString(), "Rodzaj nieruchomo�ci nie zosta� ustawiony poprawnie.");
            Assert.AreEqual(5, dom.LiczbaPokoi, "Liczba pokoi nie zosta�a ustawiona poprawnie.");
            Assert.AreEqual(120, dom.Powierzchnia, "Powierzchnia nie zosta�a ustawiona poprawnie.");
            Assert.IsTrue(dom.garaz, "Informacja o gara�u nie zosta�a ustawiona poprawnie.");
            Assert.IsTrue(dom.ogrodek, "Informacja o ogr�dku nie zosta�a ustawiona poprawnie.");
        }

        [TestMethod]
        public void TestObliczCene_WynajemZGarazemIOgrodkiem()
        {
            // arrange
            var agencja = new Agencja { NazwaAgencji = "Agencja Testowa" };
            var dom = new Dom(EnumNieruchomosc.Dom, "01-234", "Warszawa", "Mokotowska", "15", EnumRodzaj.Luksus, 5, true, true, true, 120, 2, true, true, agencja);
            var dataWynajecia = new DateTime(2025, 1, 1);
            var dataZwolnienia = new DateTime(2025, 1, 10);

            // act
            var cena = dom.ObliczCene(dataWynajecia, dataZwolnienia);

            // assert
            double kosztGarazu = 100;
            double kosztOgrodek = 100;
            double kosztPietra = 2 * 5; // 2 pi�tra x 5
            double kosztPodstawowy = (double)EnumRodzaj.Luksus * 2 * 9; // 90 * 2 * 9 dni
            double oczekiwanaCena = kosztPodstawowy + kosztGarazu + kosztOgrodek + kosztPietra;

            Assert.AreEqual(oczekiwanaCena, cena, "Cena wynajmu nie zosta�a obliczona poprawnie.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNiepoprawnyKodPocztowy_ThrowsException()
        {
            // arrange
            var agencja = new Agencja { NazwaAgencji = "Agencja Testowa" };

            // act
            new Dom(EnumNieruchomosc.Dom, "01234", "Warszawa", "Mokotowska", "15", EnumRodzaj.Standard, 4, true, true, true, 100, 1, false, true, agencja);
        }

        [TestMethod]
        public void TestToString_PoprawnyFormat()
        {
            // arrange
            var agencja = new Agencja { NazwaAgencji = "Agencja Testowa" };
            var dom = new Dom(EnumNieruchomosc.Dom, "01-234", "Warszawa", "Mokotowska", "15", EnumRodzaj.Standard, 4, true, true, true, 100, 1, true, false, agencja);

            // act
            var result = dom.ToString();

            // assert
            StringAssert.Contains(result, "Gara�: Tak", "Informacja o gara�u nie zosta�a poprawnie uwzgl�dniona w ToString.");
            StringAssert.Contains(result, "Ogr�dek: Nie", "Informacja o ogr�dku nie zosta�a poprawnie uwzgl�dniona w ToString.");
        }

        [TestMethod]
        public void TestTworzenieMieszkania_PoprawneDane()
        {
            // arrange
            var agencja = new Agencja { NazwaAgencji = "Agencja Testowa" };

            // act
            var mieszkanie = new Mieszkanie(EnumNieruchomosc.Mieszkanie, "00-123", "Krak�w", "Floria�ska", "10A", EnumRodzaj.Standard, 3, true, true, false, true, 75, 2, agencja);

            // assert
            Assert.AreEqual("00-123", mieszkanie.KodPocztowy, "Kod pocztowy nie zosta� ustawiony poprawnie.");
            Assert.AreEqual("Krak�w", mieszkanie.Miasto, "Miasto nie zosta�o ustawione poprawnie.");
            Assert.AreEqual("Standard", mieszkanie.Rodzaj.ToString(), "Rodzaj nieruchomo�ci nie zosta� ustawiony poprawnie.");
            Assert.AreEqual(3, mieszkanie.LiczbaPokoi, "Liczba pokoi nie zosta�a ustawiona poprawnie.");
            Assert.AreEqual(75, mieszkanie.Powierzchnia, "Powierzchnia nie zosta�a ustawiona poprawnie.");
            Assert.AreEqual(2, mieszkanie.pietro, "Pi�tro nie zosta�o ustawione poprawnie.");
            Assert.IsTrue(mieszkanie.balkon, "Informacja o balkonie nie zosta�a ustawiona poprawnie.");
        }

        [TestMethod]
        public void TestObliczCene_WynajemZBalkonemNaPietrze()
        {
            // arrange
            var agencja = new Agencja { NazwaAgencji = "Agencja Testowa" };
            var mieszkanie = new Mieszkanie(EnumNieruchomosc.Mieszkanie, "00-123", "Krak�w", "Floria�ska", "10A", EnumRodzaj.Podstawa, 2, true, false, false, true, 50, 3, agencja);
            var dataWynajecia = new DateTime(2025, 1, 1);
            var dataZwolnienia = new DateTime(2025, 1, 10);

            // act
            var cena = mieszkanie.ObliczCene(dataWynajecia, dataZwolnienia);

            // assert
            double kosztBalkon = 50; // Sta�y koszt balkonu
            double kosztPietro = 3 * 10; // 3 pi�tro x 10
            double kosztBazowy = (double)EnumRodzaj.Podstawa * 9; // 50 * 9 dni
            double oczekiwanaCena = kosztBazowy + kosztBalkon + kosztPietro;

            Assert.AreEqual(oczekiwanaCena, cena, "Cena wynajmu nie zosta�a obliczona poprawnie.");
        }
    }
}