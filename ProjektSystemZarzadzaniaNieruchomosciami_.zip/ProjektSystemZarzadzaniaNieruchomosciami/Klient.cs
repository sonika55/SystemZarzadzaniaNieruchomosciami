﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    public class Klient : Osoba
    {
        static int IDKlienta = 0;
        public static List<Klient> ListaKlientow { get; private set; } = new List<Klient>();

        public Klient()
        {
        }

        public Klient(string imie, string nazwisko, string numerTelefonu, string pesel, string dataUrodzenia)
            : base(imie, nazwisko, numerTelefonu, pesel, dataUrodzenia)
        {
            IDKlienta++;
            ListaKlientow.Add(this);
        }

        public override string ToString()
        {
            return $"IdKlienta: {IDKlienta}, {base.ToString()}";
        }
    }
}