﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    [DataContract]
    public class Mieszkanie : Nieruchomosc
    {
        [DataMember]
        public int pietro { get; set; }
        [DataMember]
        public bool balkon { get; set; }

        public Mieszkanie() { }

        public Mieszkanie(EnumNieruchomosc nieruch, string kodPocztowy, string miasto, string ulica, string numerDomu, EnumRodzaj rodzaj, int liczbaPokoi, bool wolny, bool zwierzeta, bool palenie, bool balkon, int powierzchnia, int pietro, Agencja agencja)
        : base(nieruch, kodPocztowy, miasto, ulica, numerDomu, rodzaj, liczbaPokoi, wolny, zwierzeta, palenie, powierzchnia, agencja)
        {
            this.pietro = pietro;
            this.balkon = balkon;
            CenaPodstawowa = UstalCenePodstawowa(rodzaj, false);
        }

        public override double ObliczCene(DateTime dataWynajecia, DateTime dataZwolnienia)
        {
            double cenaBazowa = base.ObliczCene(dataWynajecia, dataZwolnienia);

            double kosztPietro = pietro * 10;
            double kosztBalkon = balkon ? 50 : 0;

            return cenaBazowa + kosztPietro + kosztBalkon;
        }

        public override string ToString()
        {
            string CzyBalkon = balkon ? "Tak" : "Nie";
            return $"{base.ToString()}Piętro: {pietro}, Balkon: {CzyBalkon}\n";
        }
    }
}