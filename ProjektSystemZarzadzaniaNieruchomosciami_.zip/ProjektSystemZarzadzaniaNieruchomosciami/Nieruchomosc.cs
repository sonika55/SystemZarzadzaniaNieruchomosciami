﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    [DataContract]

    public enum EnumRodzaj
    {
        [EnumMember(Value = "Luksus")]
        Luksus = 90,

        [EnumMember(Value = "Standard")]
        Standard = 70,

        [EnumMember(Value = "Podstawa")]
        Podstawa = 50
    }
    public enum EnumNieruchomosc { Mieszkanie, Dom }

    [XmlInclude(typeof(Dom))]
    [XmlInclude(typeof(Mieszkanie))]
    public class Nieruchomosc : IComparable<Nieruchomosc>
    {

        private string miasto;
        private string kodPocztowy;
        private string ulica;
        private string numerDomu;
        private EnumRodzaj rodzaj;
        private int liczbaPokoi;
        private bool wolny;
        private bool zwierzeta;
        private bool palenie;
        private int powierzchnia;
        private double cenaPodstawowa;
        private EnumNieruchomosc nieruch;
        private string identyfikator;
        private static int nrObiektu;
        [DataMember]
        public Agencja? AgencjaPrzypisana { get; set; }

        public void UstawAgencje(Agencja agencja)
        {
            if (agencja == null)
            {
                throw new ArgumentNullException(nameof(agencja), "Agencja nie może być null.");
            }

            AgencjaPrzypisana = agencja;


        }
        [DataMember]
        public double CenaPodstawowa { get; set; }
        [DataMember]
        public string Identyfikator { get; set; }
        [DataMember]
        public string Miasto
        {
            get => miasto;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Miasto nie może być puste.");
                miasto = value;
            }
        }
        [DataMember]
        public string KodPocztowy
        {
            get => kodPocztowy;
            set
            {
                if (!Regex.IsMatch(value, @"^\d{2}-\d{3}$"))
                    throw new ArgumentException("Kod pocztowy musi mieć format XX-XXX.");
                kodPocztowy = value;
            }
        }
        [DataMember]
        public string Ulica
        {
            get => ulica;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Ulica nie może być pusta.");
                ulica = value;
            }
        }
        [DataMember]
        public string NumerDomu
        {
            get => numerDomu;
            set
            {
                if (string.IsNullOrWhiteSpace(value) || !Regex.IsMatch(value, @"^\d+[a-zA-Z]?$"))
                    throw new ArgumentException("Numer domu musi mieć format liczbowy.");
                numerDomu = value;
            }
        }

        public EnumRodzaj Rodzaj
        {
            get => rodzaj;
            set => rodzaj = value;
        }
        [DataMember]
        public int LiczbaPokoi
        {
            get => liczbaPokoi;
            set
            {
                if (value < 1)
                    throw new ArgumentException("Liczba pokoi musi wynosić co najmniej 1.");
                liczbaPokoi = value;
            }
        }
        [DataMember]
        public bool Wolny
        {
            get => wolny;
            set => wolny = value;
        }
        [DataMember]
        public bool Zwierzeta
        {
            get => zwierzeta;
            set => zwierzeta = value;
        }
        [DataMember]
        public bool Palenie
        {
            get => palenie;
            set => palenie = value;
        }
        [DataMember]
        public int Powierzchnia
        {
            get => powierzchnia;
            set
            {
                if (value < 10)
                    throw new ArgumentException("Powierzchnia musi wynosić co najmniej 10m².");
                powierzchnia = value;
            }
        }
        [DataMember]
        public EnumNieruchomosc Nieruch
        {
            get => nieruch;
            set => nieruch = value;
        }



        static Nieruchomosc()
        {
            nrObiektu = 0;
        }
        public Nieruchomosc() { }
        public Nieruchomosc(EnumNieruchomosc nieruch, string kodPocztowy, string miasto, string ulica, string numerDomu, EnumRodzaj rodzaj, int liczbaPokoi, bool wolny, bool zwierzeta, bool palenie, int powierzchnia, Agencja agencja)
        {
            nrObiektu++;
            this.nieruch = nieruch;
            KodPocztowy = kodPocztowy;
            Miasto = miasto;
            Ulica = ulica;
            NumerDomu = numerDomu;
            Rodzaj = rodzaj;
            LiczbaPokoi = liczbaPokoi;
            Wolny = wolny;
            Zwierzeta = zwierzeta;
            Palenie = palenie;
            Powierzchnia = powierzchnia;
            CenaPodstawowa = UstalCenePodstawowa(rodzaj, nieruch == EnumNieruchomosc.Dom);
            Identyfikator = $"{nieruch}-00{nrObiektu}";
            UstawAgencje(agencja);
        }

        public double UstalCenePodstawowa(EnumRodzaj rodzaj, bool isDom)
        {
            double cenaBazowa = (double)rodzaj;
            return isDom ? cenaBazowa * 2 : cenaBazowa;
        }

        public virtual double ObliczCene(DateTime dataWynajecia, DateTime dataZwolnienia)
        {
            if (dataWynajecia >= dataZwolnienia)
                throw new ArgumentException("Data zwolnienia musi być późniejsza niż data wynajęcia.");

            if (CenaPodstawowa <= 0)
                throw new ArgumentException("Cena podstawowa nie została poprawnie ustawiona.");

            int liczbaDni = (dataZwolnienia - dataWynajecia).Days;
            return CenaPodstawowa * liczbaDni;
        }

        public string StatusTekstowy
        {
            get => Wolny ? "wolne" : "zajęte";
        }
        new public virtual string ToString()
        {

            string zezwolenieNaPalenie = Palenie ? "Tak" : "Nie";
            string zezwolenieNaZwierze = Zwierzeta ? "Tak" : "Nie";

            return $"{Identyfikator}, {kodPocztowy} {Miasto}, {ulica} {numerDomu} \n" +
                   $"Status: {StatusTekstowy}\n" +
                   $"Cena wynajmu: {CenaPodstawowa:C}, Powierzchnia: {powierzchnia}m², Liczba pokoi: {liczbaPokoi}\n" +
                   $"Czy dozwolone zwierzęta: {zezwolenieNaZwierze}, Czy dozwolone palenie: {zezwolenieNaPalenie}\n";
        }

        public int CompareTo(Nieruchomosc? other)
        {
            if (other == null) return 1;

            return CenaPodstawowa.CompareTo(other.CenaPodstawowa);
        }

        public int PorownajPoCenieObliczonej(Nieruchomosc other, DateTime dataWynajecia, DateTime dataZwolnienia)
        {
            if (other == null) return 1;

            double cenaTej = ObliczCene(dataWynajecia, dataZwolnienia);
            double cenaInnej = other.ObliczCene(dataWynajecia, dataZwolnienia);

            return cenaTej.CompareTo(cenaInnej);
        }

        public int PorownajPoPowierzchni(Nieruchomosc other)
        {
            if (other == null) return 1;

            return powierzchnia.CompareTo(other.powierzchnia);
        }

        public static void ZapiszNieruchomoscXml(string nazwaPliku, List<Nieruchomosc> nieruchomosci)
        {
            using StreamWriter sw = new(nazwaPliku);
            XmlSerializer xs = new(typeof(List<Nieruchomosc>));
            xs.Serialize(sw, nieruchomosci);
            Console.WriteLine("Zapisano listę nieruchomości do pliku XML.");
        }
        public static List<Nieruchomosc> OdczytajNieruchomoscXml(string nazwaPliku)
        {
            if (!File.Exists(nazwaPliku))
                return new List<Nieruchomosc>();

            using StreamReader sr = new(nazwaPliku);
            XmlSerializer xs = new(typeof(List<Nieruchomosc>));
            return (List<Nieruchomosc>)xs.Deserialize(sr);
        }




    }
}