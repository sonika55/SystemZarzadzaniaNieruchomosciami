﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ProjektSystemZarzadzaniaNieruchomosciami
{
    [DataContract]
    public class Osoba
    {

        private string imie;
        private string nazwisko;
        private string numerTelefonu { get; set; }

        private string pesel;
        private string dataUrodzenia { get; set; }

        [DataMember]
        public string Pesel
        {
            get => pesel;
            set
            {
                if (!Regex.IsMatch(value, @"^\d{11}$"))
                    throw new FormatException("Pesel musi skladac sie z 11 cyfr");
                else pesel = value;
            }
        }
        [DataMember]
        public string NumerTelefonu
        {
            get => numerTelefonu;
            set
            {
                if (!Regex.IsMatch(value, @"^\d{9}$"))
                { throw new FormatException("Numer telefonu musi skladac sie z 9 cyfr"); }
                numerTelefonu = value;
            }
        }
        [DataMember]

        public string Imie
        {
            get => imie;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Imię nie może być puste.");
                }
                imie = value;
            }
        }
        [DataMember]
        public string Nazwisko
        {
            get => nazwisko;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Nazwisko nie może być puste.");
                }
                nazwisko = value;
            }
        }

        public Osoba()
        {
        }

        public Osoba(string imie, string nazwisko, string numerTelefonu, string pesel, string dataUrodzenia)
        {
            this.Imie = imie;
            this.Nazwisko = nazwisko;
            this.NumerTelefonu = numerTelefonu;
            this.Pesel = pesel;


            if (DateTime.TryParseExact(dataUrodzenia,
                new[] { "dd-MM-yyyy", "yyyy-MM-dd" },
                CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
            {
                this.dataUrodzenia = parsedDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            }
            else
            {
                throw new ArgumentException("Niepoprawny format daty urodzenia. Użyj formatu dd-MM-yyyy lub yyyy-MM-dd.");
            }
        }


        public override string ToString()
        {
            return $" {Imie} {Nazwisko} ({Pesel}), Numer telefonu: {numerTelefonu}";
        }
    }
}