﻿using ProjektSystemZarzadzaniaNieruchomosciami;

public class Program
{
    static void Main()
    {
       // funkcje zapisujące dane do XML nalezy uruchamiać pojedynczo, są niezbędne do prawidłowego działania GUI

       // ZapiszNieruchomosci(); //zapisywanie nieruchomości do XML
       // ZapiszAgencje(); //zapisywanie agencji do XML
       // ZapiszWynajecia(); //zapisywanie wynajmów do XML

       // Wynajecie.WolneNieruchomosci(); //funkcja statyczna z klasy Wynajęcie, pokazuje i sortuje wolne nieruchomości


    }

    public static List<Nieruchomosc> IstniejaceNieruchomosci() //funkcja tworzy listę nieruchomości wraz z agencjami i kierownikami
    {
        Kierownik k1CC = new("Adam", "Postupalski", "674555987", "88123498723", "02-10-1988");
        Agencja CracowCity = new("CracowCity", k1CC, "Krakow");

        Kierownik k2WC = new("Maria", "Jezierska", "645255981", "68124663724", "02-12-1968");
        Agencja WarsawCity = new("WarsawCity", k2WC, "Warszawa");

        Kierownik k3P = new("Ewelina", "Tiro", "563355945", "71056663726", "10-09-1971");
        Agencja Polanies = new("Polanies", k3P, "Konin");

        Kierownik k4GD = new("Paweł", "Nowak", "753159852", "88012233444", "15-03-1975");
        Agencja GdanskEstate = new("GdanskEstate", k4GD, "Gdansk");

        Kierownik k5WR = new("Anna", "Kowalska", "851753456", "99023344556", "20-07-1980");
        Agencja WroclawHomes = new("WroclawHomes", k5WR, "Wroclaw");

        return new List<Nieruchomosc>
    {

        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "43-160", "Krakow", "Krowodrza", "44", EnumRodzaj.Standard, 2, true, false, false, true, 30, 1, CracowCity),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "43-560", "Warszawa", "Wiolda Budryka", "5", EnumRodzaj.Standard, 2, true, true, false, false, 40, 10, WarsawCity),
        new Dom(EnumNieruchomosc.Dom, "67-789", "Warszawa", "Starowislanska", "4", EnumRodzaj.Standard, 6, true, false, false, 100, 1, true, false, WarsawCity),
        new Dom(EnumNieruchomosc.Dom, "40-678", "Konin", "Leśna", "5", EnumRodzaj.Standard, 15, true, true, true, 180, 3, true, true, Polanies),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "80-123", "Gdansk", "Dluga", "10", EnumRodzaj.Standard, 3, true, true, false, true, 50, 2, GdanskEstate),
        new Dom(EnumNieruchomosc.Dom, "81-456", "Gdansk", "Jaskrowa", "15", EnumRodzaj.Luksus, 8, true, false, true, 200, 2, true, true, GdanskEstate),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "50-001", "Wroclaw", "Kwiatowa", "22", EnumRodzaj.Standard, 2, true, true, false, false, 45, 1, WroclawHomes),
        new Dom(EnumNieruchomosc.Dom, "50-234", "Wroclaw", "Zielona", "5", EnumRodzaj.Standard, 5, true, false, true, 120, 2, true, false, WroclawHomes),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "70-321", "Szczecin", "Portowa", "8", EnumRodzaj.Podstawa, 3, true, true, false, true, 55, 3, GdanskEstate),
        new Dom(EnumNieruchomosc.Dom, "71-654", "Szczecin", "Dluga", "12", EnumRodzaj.Luksus, 7, true, false, true, 180, 1, true, true, GdanskEstate),
        new Dom(EnumNieruchomosc.Dom, "90-123", "Lodz", "Wiosenna", "25", EnumRodzaj.Podstawa, 10, true, false, true, 250, 2, true, true, WroclawHomes),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "60-789", "Poznan", "Stary Rynek", "33", EnumRodzaj.Luksus, 4, true, false, false, true, 70, 5, Polanies),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "30-456", "Krakow", "Nowa Huta", "7", EnumRodzaj.Podstawa, 1, true, true, false, false, 25, 1, CracowCity),
        new Dom(EnumNieruchomosc.Dom, "40-555", "Katowice", "Słoneczna", "19", EnumRodzaj.Standard, 9, true, true, true, 150, 1, true, false, WroclawHomes),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "44-321", "Warszawa", "Centralna", "18", EnumRodzaj.Standard, 3, true, true, false, true, 60, 3, WarsawCity),
        new Dom(EnumNieruchomosc.Dom, "50-567", "Warszawa", "Marszałkowska", "2", EnumRodzaj.Luksus, 12, true, false, true, 300, 3, true, true, WarsawCity),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "22-789", "Lublin", "Ogrodowa", "4", EnumRodzaj.Standard, 2, true, true, false, true, 35, 2, Polanies),
        new Dom(EnumNieruchomosc.Dom, "11-654", "Rzeszow", "Kosciuszki", "10", EnumRodzaj.Standard, 6, true, false, false, 110, 1, true, false, CracowCity),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "80-987", "Gdansk", "Grunwaldzka", "50", EnumRodzaj.Luksus, 4, true, false, true, true, 85, 5, GdanskEstate),
        new Dom(EnumNieruchomosc.Dom, "33-222", "Wroclaw", "Powstancow", "20", EnumRodzaj.Standard, 8, true, false, true, 140, 2, true, false, WroclawHomes),
        new Mieszkanie(EnumNieruchomosc.Mieszkanie, "12-333", "Krakow", "Florianska", "8", EnumRodzaj.Standard, 2, true, false, true, true, 40, 1, CracowCity),
        new Dom(EnumNieruchomosc.Dom, "78-555", "Poznan", "Chrobrego", "12", EnumRodzaj.Luksus, 10, true, false, true, 280, 3, true, true, Polanies)
    };

    }

    public static void ZapiszNieruchomosci() //funkcja do zapisywania nieruchomości, korzysta z zapisu do pliku XML z klasy Nieruchomosc
    {
        List<Nieruchomosc> listaNieruchomosci = IstniejaceNieruchomosci();
        string nazwaPliku = "nieruchomosci.xml";
        Nieruchomosc.ZapiszNieruchomoscXml(nazwaPliku, listaNieruchomosci);
    }


    public static List<Agencja> IstniejaceAgencje() //funkcja z listą istniejących agencji
    {
        return new List<Agencja>
    {
        new Agencja("CracowCity", new Kierownik("Adam", "Postupalski", "674555987", "88123498723", "02-10-1988"), "Krakow"),
        new Agencja("WarsawCity", new Kierownik("Maria", "Jezierska", "645255981", "68124663724", "02-12-1968"), "Warszawa"),
        new Agencja("Polanies", new Kierownik("Ewelina", "Tiro", "563355945", "71056663726", "10-09-1971"), "Konin"),
        new Agencja("GdanskEstate", new Kierownik("Paweł", "Nowak", "753159852", "88012233444", "15-03-1975"), "Gdansk"),
        new Agencja("WroclawHomes", new Kierownik("Anna", "Kowalska", "851753456", "99023344556", "20-07-1980"), "Wroclaw")
    };
    }
    public static void ZapiszAgencje() //funkcja do zapisywania agencji, korzysta z zapisu do pliku XML z klasy Agencja
    {

        string nazwaPliku = "agencje.xml";
        List<Agencja> agencje = IstniejaceAgencje();
        Agencja.ZapiszAgencjeXml(nazwaPliku, agencje);

    }

    public void WszystkieAgencjeIKierownicy()
    {
        Kierownik k1CC = new("Adam", "Postupalski", "674555987", "88123498723", "02-10-1988");
        Agencja CracowCity = new("CracowCity", k1CC, "Krakow");
        Kierownik k2WC = new("Maria", "Jezierska", "645255981", "68124663724", "02-12-1968");
        Agencja WarsawCity = new("WarsawCity", k2WC, "Warszawa");
        Kierownik k3P = new("Ewelina", "Tiro", "563355945", "71056663726", "10-09-1971");
        Agencja Polanies = new("Polanies", k3P, "Konin");

        Mieszkanie m1 = new Mieszkanie(EnumNieruchomosc.Mieszkanie, "43-160", "Krakow", "Krowodrza", "44", EnumRodzaj.Standard, 2, true, false, false, true, 30, 1, CracowCity);
        Mieszkanie m2 = new Mieszkanie(EnumNieruchomosc.Mieszkanie, "43-560", "Warszawa", "Wiolda Budryka", "5", EnumRodzaj.Standard, 2, true, true, false, false, 40, 10, WarsawCity);
        Dom d1 = new Dom(EnumNieruchomosc.Dom, "67-789", "Warszawa", "Starowislanska", "4", EnumRodzaj.Standard, 6, true, false, false, 100, 1, true, false, WarsawCity);
        Dom d2 = new Dom(EnumNieruchomosc.Dom, "40-678", "Konin", "Leśna", "5", EnumRodzaj.Standard, 15, true, true, true, 180, 3, true, true, Polanies);

    }

    public static void IstniejaceWynajmy() //funkcja tworzy listę z klientami i przypisuje im wynajęcia
    {

        List<Klient> klienci = new List<Klient>
    {
        new Klient("Leopold", "Grzybek", "555101202", "92345678901", "1992-04-12"),
        new Klient("Diana", "Miodowa", "555203304", "98765432101", "1998-07-20"),
        new Klient("Kajetan", "Kos", "555405506", "88567890123", "1988-11-05"),
        new Klient("Nela", "Jaskółka", "567607708", "45678901234", "1945-02-25"),
        new Klient("Tymoteusz", "Kruk", "778809901", "56789012345", "1956-08-18"),
        new Klient("Hortensja", "Zięba", "344555666", "89012345678", "1989-05-21"),
        new Klient("Iwo", "Orzeł", "445677653", "90123456789", "1990-12-30"),
        new Klient("Amadeusz", "Gawron", "665999000", "01234567890", "2001-06-16"),
        new Klient("Kalina", "Kowalik", "555123789", "48223344556", "1948-01-02"),
        new Klient("Eryk", "Wróbel", "555456789", "02334455667", "2002-08-14"),
        new Klient("Klementyna", "Sójka", "887789123", "39445566778", "1939-11-03"),
        new Klient("Leon", "Czapla", "334321654", "44556677889", "1944-07-25"),
        new Klient("Róża", "Gołąb", "666778866", "55667788990", "1955-04-09"),
         new Klient("Jan", "Faruga", "643258866", "83778899009", "1983-04-09")
    };


        List<Nieruchomosc> nieruchomosci = IstniejaceNieruchomosci();

        List<(string DataWynajecia, string DataZwolnienia)> datyWynajmu = new List<(string, string)>
    {
      ("01-01-2023", "06-01-2023"),
      ("02-01-2023", "07-01-2023"),
      ("03-01-2023", "08-01-2023"),
      ("04-02-2023", "09-02-2023"),
      ("05-01-2023", "10-01-2023"),
      ("07-04-2024", "14-04-2024"),
      ("23-10-2024", "30-10-2024"),
      ("12-07-2024", "30-07-2024"),
      ("12-08-2024", "31-08-2024"),
      ("03-12-2024", "12-12-2024"),
      ("05-10-2024", "07-10-2024"),
      ("02-01-2025", "12-01-2025"),
      ("06-01-2025", "08-01-2025"),
      ("10-01-2025", "13-01-2025")

    };


        for (int i = 0; i < klienci.Count; i++)
        {
            var wolnaNieruchomosc = nieruchomosci.FirstOrDefault(n => Wynajecie.CzyWolna(n));
            if (wolnaNieruchomosc != null)
            {
                try
                {

                    var (dataWynajecia, dataZwolnienia) = datyWynajmu[i];
                    var wynajecie = new Wynajecie(klienci[i], wolnaNieruchomosc, dataWynajecia, dataZwolnienia);
                    Wynajecie.DodajWynajecie(wynajecie);

                    Console.WriteLine($"Przypisano klienta {klienci[i].Imie} {klienci[i].Nazwisko} do nieruchomości {wolnaNieruchomosc.Identyfikator}. Wynajem od {dataWynajecia} do {dataZwolnienia}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd podczas przypisywania wynajęcia: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine($"Brak wolnych nieruchomości dla klienta {klienci[i].Imie} {klienci[i].Nazwisko}.");
            }
        }

    }

    public static void ZapiszWynajecia() //funkcja do zapisania wynajęć do pliku XML
    {
        IstniejaceWynajmy();
        string nazwaPliku = "wynajmy.xml";
        Wynajecie.ZapiszWynajmyXml(nazwaPliku);
    }

}