﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjektZarzadzanieGUI
{
    /// <summary>
    /// Logika interakcji dla klasy DodajNieruchomosc.xaml
    /// </summary>
    public partial class DodajNieruchomosc : Window
    {
        public Nieruchomosc NowaNieruchomosc { get; private set; }
        private List<Agencja> agencje;

        public DodajNieruchomosc(List<Agencja> agencjeLista)
        {
            InitializeComponent();
            agencje = agencjeLista;
            LoadAgencje();
            InicjalizujComboBoxy();
        }

        private void LoadAgencje()
        {
            try
            {

                agencje = Agencja.OdczytajAgencjeXml("agencje.xml") ?? new List<Agencja>();

                if (!agencje.Any())
                {
                    MessageBox.Show("Brak agencji w pliku XML.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                cbAgencja.ItemsSource = agencje;
                cbAgencja.DisplayMemberPath = "NazwaAgencji";
                cbAgencja.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas wczytywania agencji: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InicjalizujComboBoxy()
        {
            cbStandard.ItemsSource = Enum.GetValues(typeof(EnumRodzaj));
            cbCzyWolne.ItemsSource = new List<string> { "Wolne", "Zajęte" };
            cbCzyWolne.SelectedIndex = 0;
        }

        private Dom UtworzDom(EnumRodzaj standard, string kodPocztowy, string miasto, string ulica, string numer, int liczbaPokoi, bool czyWolne, int powierzchnia, Agencja agencja)
        {
            return new Dom(
                EnumNieruchomosc.Dom,
                kodPocztowy,
                miasto,
                ulica,
                numer,
                standard,
                liczbaPokoi,
                czyWolne,
                false, // zwierzeta 
                true, // ogrzewanie - wartość domyślna
                powierzchnia,
                2,    // liczba pięter - wartość domyślna
                false, // garaz - wartość domyślna
                true, //ogrod
                agencja
            );
        }

        private Mieszkanie UtworzMieszkanie(EnumRodzaj standard, string kodPocztowy, string miasto, string ulica, string numer, int liczbaPokoi, bool czyWolne, int powierzchnia, int pietro, Agencja agencja)
        {
            return new Mieszkanie(
                EnumNieruchomosc.Mieszkanie,
                kodPocztowy,
                miasto,
                ulica,
                numer,
                standard,
                liczbaPokoi,
                czyWolne,
                false, // garaż 
                true, // ogrzewanie 
                false, // balkon 
                powierzchnia,
                pietro,
                agencja
            );
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                var typ = rbDom.IsChecked == true ? EnumNieruchomosc.Dom : EnumNieruchomosc.Mieszkanie;
                var agencja = (Agencja)cbAgencja.SelectedItem ?? throw new InvalidOperationException("Musisz wybrać agencję.");

                var kodPocztowy = tbKodPocztowy.Text;
                var miasto = tbMiasto.Text;
                var ulica = tbUlica.Text;
                var numer = tbNumer.Text;
                var standard = (EnumRodzaj)cbStandard.SelectedItem;
                var powierzchnia = int.Parse(tbPowierzchnia.Text);
                var liczbaPokoi = int.Parse(tbPokoje.Text);
                var czyWolne = (string)cbCzyWolne.SelectedItem == "Wolne";


                NowaNieruchomosc = typ == EnumNieruchomosc.Dom
                    ? UtworzDom(standard, kodPocztowy, miasto, ulica, numer, liczbaPokoi, czyWolne, powierzchnia, agencja)
                    : UtworzMieszkanie(standard, kodPocztowy, miasto, ulica, numer, liczbaPokoi, czyWolne, powierzchnia, int.Parse(tbPietro.Text), agencja);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}