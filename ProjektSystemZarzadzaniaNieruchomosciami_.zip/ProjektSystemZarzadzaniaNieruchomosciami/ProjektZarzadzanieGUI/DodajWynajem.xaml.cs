﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjektZarzadzanieGUI
{
    /// <summary>
    /// Logika interakcji dla klasy DodajWynajem.xaml
    /// </summary>
    public partial class DodajWynajem : Window
    {
        private List<Nieruchomosc> nieruchomosci;

        public DodajWynajem()
        {
            InitializeComponent();
            WczytajNieruchomosci();
        }

        private void WczytajNieruchomosci()
        {
            try
            {
                string xmlFilePath = "nieruchomosci.xml";


                nieruchomosci = Nieruchomosc.OdczytajNieruchomoscXml(xmlFilePath) ?? new List<Nieruchomosc>();

                if (!nieruchomosci.Any())
                {
                    MessageBox.Show("Nie znaleziono nieruchomości w pliku XML.", "Błąd");
                    return;
                }


                cmbNieruchomosc.ItemsSource = nieruchomosci.Select(n => n.Identyfikator).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd podczas wczytywania nieruchomości: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAddWynajem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbNieruchomosc.SelectedItem == null)
                {
                    MessageBox.Show("Wybierz nieruchomość.", "Błąd");
                    return;
                }


                var wynajetyObiekt = nieruchomosci.FirstOrDefault(n => n.Identyfikator == cmbNieruchomosc.SelectedItem.ToString());
                if (wynajetyObiekt == null) throw new Exception("Nie znaleziono wybranej nieruchomości.");

                Wynajecie wynajecie = new Wynajecie
                {
                    wynajecieKlient = new Klient(txtImie.Text, txtNazwisko.Text, txtNumerTelefonu.Text, txtPesel.Text, txtDataUrodzenia.Text),
                    wynajetyObiekt = wynajetyObiekt,
                    DataWynajecia = dpDataWynajecia.SelectedDate ?? throw new Exception("Wybierz datę wynajęcia."),
                    DataZwolnienia = dpDataZwolnienia.SelectedDate ?? throw new Exception("Wybierz datę zwolnienia.")
                };

                Wynajecie.DodajWynajecie(wynajecie);
                Wynajecie.ZapiszWynajmyXml("wynajmy.xml");

                MessageBox.Show("Wynajem dodany pomyślnie", "Sukces", MessageBoxButton.OK);
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

}
