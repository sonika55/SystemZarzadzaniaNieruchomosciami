﻿using System.Windows;
using System.Windows.Controls;
using System.Text;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjektZarzadzanieGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Obsługa przyciskow glownego ekranu
        private void OpenPropertyManagement(object sender, RoutedEventArgs e)
        {
            var nieruchomosciWindow = new ZarzadzajNieruchomosciami();
            nieruchomosciWindow.ShowDialog();
        }
        private void OpenAgencyManagement(object sender, RoutedEventArgs e)
        {
            var agencjeWindow = new ZarzadzajAgencjami();
            agencjeWindow.ShowDialog();
        }
        private void CloseApp(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void OpenWolneNieruchomosci_Click(object sender, RoutedEventArgs e)
        {
            WolneNieruchomosci window = new WolneNieruchomosci();
            window.ShowDialog();
        }

        private void OpenZarzadzajWynajmem_Click(object sender, RoutedEventArgs e)
        {
            ZarzadzajWynajmem Wynajmy = new ZarzadzajWynajmem();
            Wynajmy.ShowDialog();
        }

    }
}