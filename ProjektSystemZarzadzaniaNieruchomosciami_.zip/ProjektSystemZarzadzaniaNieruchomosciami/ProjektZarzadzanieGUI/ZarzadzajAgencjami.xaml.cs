﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjektZarzadzanieGUI
{
    /// <summary>
    /// Logika interakcji dla klasy ZarzadzajAgencjami.xaml
    /// </summary>
    public partial class ZarzadzajAgencjami : Window
    {
        private List<Agencja> agencje;
        private string nazwaPliku = "agencje.xml";

        public ZarzadzajAgencjami()
        {
            InitializeComponent();
            LoadAgencies();
        }

        private void LoadAgencies()
        {
            agencje = Agencja.OdczytajAgencjeXml(nazwaPliku) ?? new List<Agencja>();
            RefreshDataGrid();
        }

        private void BtnAddAgency_Click(object sender, RoutedEventArgs e)
        {
            string nazwa = tbAgencyName.Text;
            string miasto = tbCity.Text;
            string nazwiskoKierownika = tbManager.Text;

            Agencja nowaAgencja = new Agencja(nazwa, new Kierownik("Imię", nazwiskoKierownika, "123456789", "12345678901", "1970-01-01"), miasto);

            agencje.Add(nowaAgencja);
            Agencja.ZapiszAgencjeXml(nazwaPliku, agencje);
            RefreshDataGrid();
            tbAgencyName.Clear();
            tbCity.Clear();
            tbManager.Clear();
        }

        private void BtnDeleteAgency_Click(object sender, RoutedEventArgs e)
        {
            if (dgAgencies.SelectedItem is Agencja selectedAgency)
            {
                agencje.Remove(selectedAgency);
                Agencja.ZapiszAgencjeXml(nazwaPliku, agencje);
                RefreshDataGrid();
            }
            else
            {
                MessageBox.Show("Proszę wybrać agencję do usunięcia.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void RefreshDataGrid()
        {
            dgAgencies.ItemsSource = null;
            dgAgencies.ItemsSource = agencje;
        }
    }

}