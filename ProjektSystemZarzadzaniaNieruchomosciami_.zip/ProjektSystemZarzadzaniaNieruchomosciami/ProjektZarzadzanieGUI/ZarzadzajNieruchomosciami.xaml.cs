﻿using ProjektSystemZarzadzaniaNieruchomosciami;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjektZarzadzanieGUI
{
    /// <summary>
    /// Logika interakcji dla klasy ZarzadzajNieruchomosciami.xaml
    /// </summary>
    public partial class ZarzadzajNieruchomosciami : Window
    {
        private int ostatniNumer = 0;
        private List<Nieruchomosc> nieruchomosci;
        private string nazwaPliku = "nieruchomosci.xml";

        public ZarzadzajNieruchomosciami()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            LoadNieruchomosci();
            LoadCityFilter();
            RefreshDataGrid();
        }

        private void RefreshDataGrid() //funkcja do odswiezania
        {
            dgNieruchomosci.ItemsSource = null;
            dgNieruchomosci.ItemsSource = nieruchomosci;
        }

        private void LoadNieruchomosci()
        {
            if (System.IO.File.Exists(nazwaPliku))
            {
                nieruchomosci = Nieruchomosc.OdczytajNieruchomoscXml(nazwaPliku) ?? new List<Nieruchomosc>();
            }
            else
            {
                nieruchomosci = new List<Nieruchomosc>();
                MessageBox.Show("Plik XML nie został znaleziony.");
            }

            if (nieruchomosci.Any())
            {
                ostatniNumer = nieruchomosci.Select(n => int.Parse(n.Identyfikator.Split('-')[1])).DefaultIfEmpty(0).Max();
            }
        }

        private void LoadCityFilter()
        {
            var miasta = nieruchomosci.Select(n => n.Miasto).Distinct().OrderBy(m => m).ToList();
            cbCityFilter.ItemsSource = new List<string> { "Wszystkie" }.Concat(miasta).ToList();
            cbCityFilter.SelectedIndex = 0;
        }


        private void BtnAgencies_Click(object sender, RoutedEventArgs e) //obsługa przycisku do zarządzania agencjami
        {
            ZarzadzajAgencjami agenciesWindow = new ZarzadzajAgencjami();
            agenciesWindow.ShowDialog();
        }
        private void CbCityFilter_SelectionChanged(object sender, SelectionChangedEventArgs e) //filtrowanie miast po zmianie
        {
            if (cbCityFilter.SelectedItem != null)
            {
                string selectedCity = cbCityFilter.SelectedItem.ToString();
                if (selectedCity == "Wszystkie")
                {
                    dgNieruchomosci.ItemsSource = nieruchomosci;
                }
                else
                {
                    var filtered = nieruchomosci.Where(n => n.Miasto == selectedCity).ToList();
                    dgNieruchomosci.ItemsSource = filtered;
                }
            }
        }

        private void BtnDetails_Click(object sender, RoutedEventArgs e)
        {
            if (dgNieruchomosci.SelectedItem is Nieruchomosc selected)
            {

                MessageBox.Show(selected.ToString(), "Szczegóły nieruchomości", MessageBoxButton.OK, MessageBoxImage.None);
            }
            else
            {
                MessageBox.Show("Proszę wybrać nieruchomość, aby zobaczyć szczegóły.", "Informacja", MessageBoxButton.OK, MessageBoxImage.None);
            }
        }



        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var agencje = Program.IstniejaceAgencje();
            DodajNieruchomosc addWindow = new DodajNieruchomosc(agencje);
            bool? result = addWindow.ShowDialog();

            if (result == true) // gdy użytkownik doda nieruchomość
            {

                ostatniNumer++;
                var typ = addWindow.NowaNieruchomosc.Nieruch.ToString();
                addWindow.NowaNieruchomosc.Identyfikator = $"{typ}-00{ostatniNumer}";
                nieruchomosci.Add(addWindow.NowaNieruchomosc);
                RefreshDataGrid();
                SaveDataToXml();
            }
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (dgNieruchomosci.SelectedItem is Nieruchomosc selected)
            {
                nieruchomosci.Remove(selected);
                RefreshDataGrid();
                SaveDataToXml();
            }
            else
            {
                MessageBox.Show("Proszę wybrać nieruchomość do usunięcia.");
            }
        }

        private void SaveDataToXml()
        {
            Nieruchomosc.ZapiszNieruchomoscXml(nazwaPliku, nieruchomosci);
        }
    }
}
