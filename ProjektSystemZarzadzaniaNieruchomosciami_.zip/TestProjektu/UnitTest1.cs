using ProjektSystemZarzadzaniaNieruchomosciami;

namespace TestProjektu
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPustaNazwaAgencji()
        {
            // arrange & action
            Agencja agencja = new() { NazwaAgencji = "" };

            // assert
            Assert.Fail("Nie powinno by� mo�liwe ustawienie pustej nazwy agencji.");
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullowyKierownikAgencji()
        {
            // arrange & action
            Agencja agencja = new() { KierownikAgencji = null };

            // assert
            Assert.Fail("Nie powinno by� mo�liwe ustawienie nullowego kierownika agencji.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPusteMiastoAgencji()
        {
            // arrange & action
            Agencja agencja = new() { Miasto = "" };

            // assert
            Assert.Fail("Nie powinno by� mo�liwe ustawienie pustej warto�ci dla miasta.");
        }


        [TestMethod]
        public void TestDodawaniaAgencjiDoListy()
        {
            // arrange
            Agencja agencja1 = new("Agencja1", new Kierownik("Jan", "Kowalski", "111222333", "12344567789", "13-06-1978"), "Warszawa");
            Agencja agencja2 = new("Agencja2", new Kierownik("Anna", "Nowak", "444555666", "54561456827", "21-05-1990"), "Krak�w");
            List<Agencja> agencje = new();

            // action
            agencje.Add(agencja1);
            agencje.Add(agencja2);

            // assert
            Assert.AreEqual(2, agencje.Count, "Lista agencji powinna zawiera� 2 elementy.");
            Assert.IsTrue(agencje.Contains(agencja1), "Lista powinna zawiera� agencj� 1.");
            Assert.IsTrue(agencje.Contains(agencja2), "Lista powinna zawiera� agencj� 2.");
        }
    }
}